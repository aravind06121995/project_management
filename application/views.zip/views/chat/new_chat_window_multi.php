<div class="chat-body-wrap">
<div id="chat-body-errors"></div>
<p><?php echo lang("ctn_1321") ?></p>
<p class="ui-front"><input type="text" name="name" class="form-control" placeholder="<?php echo lang("ctn_1322") ?>" id="start_chat_username"></p>
<p><input type="text" name="reply" class="form-control" id="start_chat_title" placeholder="<?php echo lang("ctn_1314") ?>"></p>
<p><input type="text" name="reply" class="form-control" id="start_chat_message" placeholder="<?php echo lang("ctn_1319") ?>"></p>
<p><input type="button" class="btn btn-default btn-sm form-control" value="<?php echo lang("ctn_1320") ?>" id="start_chat_button"></p>

</div>