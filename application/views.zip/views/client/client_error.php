<div class="white-area-content">
<h4><?php echo lang("ctn_133") ?></h4>
<b><?php echo lang("ctn_134") ?></b>: <?php echo $message ?><br /><br />
<p><input type="button" value="<?php echo lang("ctn_135") ?>" onclick="window.history.back()" class="btn btn-default btn-sm" /> </p>
</div>