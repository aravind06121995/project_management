<div class="white-area-content">

<div class="db-header clearfix">
    <div class="page-header-title"> <span class="glyphicon glyphicon-file"></span> <?php echo lang("ctn_463") ?></div>
    <div class="db-header-extra form-inline"> 
     

<style type="text/css">

  .orderlist {
    margin: 2%;
    display: inline-flex;
    position: relative;
  }

  .orderlist1:hover .trash {
      opacity: 1;
      z-index: 99;
      position: absolute;
  }

  .orderlist1:after {
   
    width: 150px;
    height: 150px;
    position: absolute;
    display: block;
    background: rgba(0, 0, 0, 0.6);
    top: 0;
    z-index: 0;
    opacity: 0;
    transition: all .5s ease-in-out;
}
.orderlist1:hover:after{
    opacity: 1;
}
  

  img {

    border-radius: 5%;
    cursor: pointer;
  }



  .trash {
    position: absolute;
    right: -15px;
    top: -5px;
    margin-top: 4px;
    border: none;
    cursor: pointer;
    opacity: 0;
    display: block;
    transition: all .5s ease-in-out;
  }
   

  
</style>

    <div class="form-group has-feedback no-margin">
<div class="input-group">
<input type="text" class="form-control input-sm" placeholder="Search ..." id="form-search-input" />
<div class="input-group-btn">
    <input type="hidden" id="search_type" value="0">
        <button type="button" class="btn btn-info btn-sm dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
<span class="glyphicon glyphicon-search" aria-hidden="true"></span></button>
        <ul class="dropdown-menu small-text" style="min-width: 90px !important; left: -90px;">
          <li><a href="#" onclick="change_search(0)"><span class="glyphicon glyphicon-ok" id="search-like"></span> <?php echo lang("ctn_355") ?></a></li>
          <li><a href="#" onclick="change_search(1)"><span class="glyphicon glyphicon-ok no-display" id="search-exact"></span> <?php echo lang("ctn_356") ?></a></li>
          <li><a href="#" onclick="change_search(2)"><span class="glyphicon glyphicon-ok no-display" id="name-exact"></span> <?php echo lang("ctn_484") ?></a></li>
          <li><a href="#" onclick="change_search(3)"><span class="glyphicon glyphicon-ok no-display" id="type-exact"></span> <?php echo lang("ctn_485") ?></a></li>
          <li><a href="#" onclick="change_search(4)"><span class="glyphicon glyphicon-ok no-display" id="user-exact"></span> <?php echo lang("ctn_357") ?></a></li>
        </ul>
      </div><!-- /btn-group -->
</div>
</div>

    <a href="<?php echo site_url("files/add_file/" . $folder_parent) ?>" class="btn btn-primary btn-sm"><?php echo lang("ctn_486") ?></a>
</div>
</div>

<ol class="breadcrumb">
  <?php if(count($folders) == 0) : ?>
  <li class="active"><?php echo lang("ctn_487") ?></li>
<?php else : ?>
  <li><a href="<?php echo site_url("files") ?>"><?php echo lang("ctn_487") ?></a></li>
<?php endif; ?>
  <?php foreach($folders as $folder) : ?>
    <?php if($folder->ID == $folder_parent) : ?>
      <li class="active"><?php echo $folder->file_name ?></li>
    <?php else : ?>
      <li><a href="<?php echo site_url("files/".$page."/" . $folder->ID) ?>"><?php echo $folder->file_name ?></a></li>
    <?php endif; ?>
  <?php endforeach; ?>
</ol>
      <div id="gallery">
      
      </div>

       <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Modal Header</h4>
        </div>
        <div class="modal-body">
          <p>body</p>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>






  <script type="text/javascript">
    $(document).ready(function() {
      $.ajax({
        url: "<?php echo site_url("files/file_page1/" . $page . "/" . $folder_parent . "/" . $projectid ) ?>",
        type : 'GET'
      }).done(function(data){
        $("#gallery").html(data);
      })
    });
  </script>


</div>





<!-- 
  <td><?php echo lang("ctn_488") ?></td><td><?php echo lang("ctn_489") ?></td><td><?php echo lang("ctn_490") ?></td><td><?php echo lang("ctn_491") ?></td><td><?php echo lang("ctn_492") ?></td><td><?php echo lang("ctn_52") ?></td><td>Uploaded image</td></tr>
</thead> -->

<!-- 

<script type="text/javascript">
$(document).ready(function() {

   var st = $('#search_type').val();
    var table = $('#files-table').DataTable({
        "dom" : "B<'row'<'col-sm-12'tr>>" +
                "<'row'<'col-sm-5'i><'col-sm-7'p>>",
      "processing": false,
        "pagingType" : "full_numbers",
        "pageLength" : 15,
        "serverSide": true,
        "orderMulti": false,
        buttons: [
          { "extend": 'copy', "text":'<?php echo lang("ctn_1551") ?>',"className": 'btn btn-default btn-sm' },
          { "extend": 'csv', "text":'<?php echo lang("ctn_1552") ?>',"className": 'btn btn-default btn-sm' },
          { "extend": 'excel', "text":'<?php echo lang("ctn_1553") ?>',"className": 'btn btn-default btn-sm' },
          { "extend": 'pdf', "text":'<?php echo lang("ctn_1554") ?>',"className": 'btn btn-default btn-sm' },
          { "extend": 'print', "text":'<?php echo lang("ctn_1555") ?>',"className": 'btn btn-default btn-sm' }
        ],
        "order": [
          [0, "asc" ]
        ],
        "columns": [
        null,
        null,
        null,
        null,
        { "orderable": false },
        { "orderable": false },
        { "orderable": false }
    ],
        "ajax": {
            url : "<?php echo site_url("files/file_page/" . $page . "/" . $folder_parent . "/" . $projectid ) ?>",
            type : 'GET',
            data : function ( d ) {
                d.search_type = $('#search_type').val();
            }
        },
        "drawCallback": function(settings, json) {
        $('[data-toggle="tooltip"]').tooltip();
      }
    });
    $('#form-search-input').on('keyup change', function () {
    table.search(this.value).draw();
});

} );
function change_search(search) 
    {
      var options = [
        "search-like", 
        "search-exact",
        "name-exact",
        "type-exact",
        "user-exact"
      ];
      set_search_icon(options[search], options);
        $('#search_type').val(search);
        $( "#form-search-input" ).trigger( "change" );
    }

function set_search_icon(icon, options) 
    {
      for(var i = 0; i<options.length;i++) {
        if(options[i] == icon) {
          $('#' + icon).fadeIn(10);
        } else {
          $('#' + options[i]).fadeOut(10);
        }
      }
    }
</script> -->
